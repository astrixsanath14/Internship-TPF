"""Unit tests for beacontools."""
