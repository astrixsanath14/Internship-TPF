"""Packets supported by the parser."""
from .eddystone import EddystoneFrame
from .ibeacon import IBeaconAdvertisingPacket
