Many thanks to everyone who contributed to this project:
(in chronological order)

- miek (https://github.com/miek)
- marcosmoreno (https://github.com/marcosmoreno)
- darkskiez (https://github.com/darkskiez) Google LLC
